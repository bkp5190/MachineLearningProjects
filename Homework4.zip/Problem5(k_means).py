import numpy as np
import scipy as sp
import pandas as pd
import matplotlib.pyplot as plt
import random
from numpy.random import choice
import sys
#def part_one():
    #Loading in the data using pandas
iris = pd.read_csv('iris.data')
    #Empty list to hold the different colors
col = []
    #Set each color according to the label given by the data file as specified in the directions
for i in range(0, len(iris)):
    if iris['class'][i] == 'Iris-setosa':
        col.append('cyan')
    if iris['class'][i] == 'Iris-versicolor':
        col.append('purple')
    if iris['class'][i] == 'Iris-virginica':
        col.append('yellow')
    #Compute x1 and x2 values as told by the directions
x1 = iris['sepal length'] / iris['sepal width']
x2 = iris['petal length'] / iris['petal width']
    #Plot the points in form (x1, x2) and pass in color list for the different labels
for i in range(len(x1)):
    plt.scatter(x1[i], x2[i], c=col[i], s=150, linewidth=0)
plt.show()

def k_init(X, k):
    """ k-means++: initialization algorithm

    Parameters
    ----------
    X: array, shape(n ,d)
        Input array of n samples and d features

    k: int
        The number of clusters

    Returns
    -------
    init_centers: array (k, d)
        The initialize centers for kmeans++
    """
    #Setting the correct dimensions for the initialized centers array
    n, dim = X.shape
    init_centers = np.zeros((k, dim))
    
    #Counter for the number of centers
    num_centers = 1

    #Set the first center to be a random point within the data
    init_centers[0] = random.choice(X)
    
    #Iterate through the rest of the centers that need to be initialized
    for i in range(1,k):
        #Create new arrays for the distances and probabilities
        dist = np.zeros(len(X))
        prob = np.zeros(len(X))
        #Counter to increment through the distances
        counter = 0;
        #Iterate through all of the data points
        for j in range(n):
            #Set variables to hold all of the x and y points for distance computation
            x_point = X[j][0]
            y_point = X[j][1]
            #Preset a value to the highest possible value allowed for comparison
            comp = sys.maxsize
            temp = 0
            #Iterate through all of the centers
            for k in range(0, num_centers):
                #Distance computation
                temp = ((x_point - init_centers[k][0])**2 + (y_point - init_centers[k][1])**2)
                #Find shortest distances and add them to the array
                if temp < comp:
                    comp = temp
            dist[j] = comp
            counter += dist[j]
        #Calculating the probability of the remaining points
        for j in range(n): 
            prob[j] = dist[j]/counter
        #Set the rest of the centers based on the weights of probabilities
        next_c = random.choices(X, cum_weights = prob, k = 1)
        init_centers[i] = np.array(next_c) 
        num_centers += 1
    #Return the final set of initialized centers
    return init_centers

#This function was solely used for testing if the initial centers were set correctly on the data set
def init_test():
    #Set the X array based on the data set
    X = np.zeros([150, 2])
    for i in range(0, len(x1)):
        X[i] = (x1[i], x2[i])
    #Initialize 3 centers
    k = 3
    #Print the results
    sols = k_init(X, k)
    print("Solution", sol)
    #Plot the points again
    for i in range(len(x1)):
        plt.scatter(x1[i], x2[i], c = col[i], s = 150, linewidth = 0)

    #Plot the new found initial centers in black
    for i in range(0, len(Results)):
            plt.scatter(Results[i][0], Results[i][1], c = 'black', s = k, linewidth = 3)

    plt.show()

def k_means_pp(X, k, max_iter):
    """ k-means++ clustering algorithm

    step 1: call k_init() to initialize the centers
    step 2: iteratively refine the assignments

    Parameters
    ----------
    X: array, shape(n ,d)
        Input array of n samples and d features

    k: int
        The number of clusters

    max_iter: int
        Maximum number of iteration

    Returns
    -------
    final_centers: array, shape (k, d)
        The final cluster centers
    """
    #Retrieve the inital centers by calling k_init and set it to the final_centers variable which will be later returned
    final_centers = k_init(X, k)
    #Set an array to hold distances of each point to the closest center
    dist = np.zeros(len(X))
    center_assigned = 0
    objective_value = np.zeros(max_iter)
    for t in range(1, max_iter):
        n, d = X.shape
        bit_map = assign_data2clusters(X, final_centers)
        # Denominator
        num_points = np.zeros([k])
        x_sum = np.zeros([k])
        y_sum = np.zeros([k])
        updated_center_x_value = np.zeros([k])
        updated_center_y_value = np.zeros([k])
        dist_to_centers = np.zeros([k])
        min_dist_to_center = np.zeros([k])
        dist = np.zeros(len(X))
        temp = 0
        center_assigned = 0
        min_d = sys.maxsize
        

        for j in range(n):
            x_point = X[j][0]
            y_point = X[j][1]

            for s in range(0, len(final_centers)):

                num_points[s] = num_points[s] + bit_map[j][s]

                
                if(bit_map[j][s] == 1):
                    x_sum[s] = x_sum[s] + x_point
                    y_sum[s] = y_sum[s] + y_point

        for s in range(0, k):
            updated_center_x_value[s] = x_sum[s]/num_points[s]
            updated_center_y_value[s] = y_sum[s]/num_points[s]
            final_centers[s] = ([updated_center_x_value[s], updated_center_y_value[s]]) 
        
        #Call the compute objective function 
        objective_value[t] = compute_objective(X, final_centers)
        
        
        center_colors = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])
             for i in range(k)]                                                         
        
        for i in range(n):
            for j in range(0, k):
                    if bit_map[i][j] == 1: 
                        col[i] = center_colors[j]

        #objective_value = np.delete(objective_value, 0)
        plt.plot(range(0, max_iter), objective_value)
        plt.show()

    return final_centers
# I created a new helper function which does the same thing as k-means without the plot to use within compute_objective because I did not want the function printing 50 times
def k_means_pp_helper(X, k, max_iter):
    """ k-means++ clustering algorithm

    step 1: call k_init() to initialize the centers
    step 2: iteratively refine the assignments

    Parameters
    ----------
    X: array, shape(n ,d)
        Input array of n samples and d features

    k: int
        The number of clusters

    max_iter: int
        Maximum number of iteration

    Returns
    -------
    final_centers: array, shape (k, d)
        The final cluster centers
    """
    final_centers = k_init(X, k)
    dist = np.zeros(len(X))
    center_assigned = 0
    objective_value = np.zeros(max_iter)
    for t in range(1, max_iter):
        n, d = X.shape
        bit_map = assign_data2clusters(X, final_centers)
        # Denominator
        num_points = np.zeros([k])
        x_sum = np.zeros([k])
        y_sum = np.zeros([k])
        updated_center_x_value = np.zeros([k])
        updated_center_y_value = np.zeros([k])
        dist_to_centers = np.zeros([k])
        min_dist_to_center = np.zeros([k])
        dist = np.zeros(len(X))
        temp = 0
        center_assigned = 0
        min_d = sys.maxsize
        

        for j in range(n):
            x_point = X[j][0]
            y_point = X[j][1]

            for s in range(0, len(final_centers)):

                num_points[s] = num_points[s] + bit_map[j][s]

                
                if(bit_map[j][s] == 1):
                    x_sum[s] = x_sum[s] + x_point
                    y_sum[s] = y_sum[s] + y_point

        for s in range(0, k):
            updated_center_x_value[s] = x_sum[s]/num_points[s]
            updated_center_y_value[s] = y_sum[s]/num_points[s]
            final_centers[s] = ([updated_center_x_value[s], updated_center_y_value[s]]) 
        
        objective_value[t] = compute_objective(X, final_centers)
        
        # Found a way to assign colors randomly from an online implementation
        center_colors = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])
             for i in range(k)]                                                         
        # Check 
        for i in range(n):
            for j in range(0, k):
                    if bit_map[i][j] == 1: 
                        col[i] = center_colors[j]

    return final_centers

def assign_data2clusters(X, C):
    """ Assignments of data to the clusters
    Parameters
    ----------
    X: array, shape(n ,d)
        Input array of n samples and d features

    C: array, shape(k ,d)
        The final cluster centers

    Returns
    -------
    data_map: array, shape(n, k)
        The binary matrix A which shows the assignments of data points (X) to
        the input centers (C).
    """
    n, d = X.shape
    k = C.shape[0]
    data_map = np.zeros([n, k])
    dist = np.zeros(len(X))
    for j in range(n):
        temp = 0
        x_point = X[j][0]
        y_point = X[j][1]
        min_d = sys.maxsize
        for s in range(len(C)):
            temp = ((x_point - C[s][0])**2 + (y_point - C[s][1])**2)
            if temp <= min_d:
                center = s
                min_d = temp
        data_map[j][center] = 1
        dist[j] = min_d
    return data_map


def compute_objective(X, C):
    """ Compute the clustering objective for X and C
    Parameters
    ----------
    X: array, shape(n ,d)
        Input array of n samples and d features

    C: array, shape(k ,d)
        The final cluster centers

    Returns
    -------
    accuracy: float
        The objective for the given assigments
    """
    n, d = X.shape
    k = C.shape[0]
    dist_to_centers = np.zeros([k])
    min_dist_to_center = np.zeros([k])
    dist = np.zeros(len(X))
    for j in range(n):
        temp = 0
        center_assigned = 0
        min_d = sys.maxsize
        x_point = X[j][0]
        y_point = X[j][1]
        for s in range(0, len(C)):
            temp = ((x_point - C[s][0])**2 + (y_point - C[s][1])**2)
            if temp < min_d:
                center_assigned = s
                min_d = temp           
        dist[j] = min_d
        dist_to_centers[center_assigned] = dist_to_centers[center_assigned] + dist[j]
    final_dist = np.array(dist_to_centers)
    final_dist = np.sum(dist_to_centers)   
    
    return final_dist

def part_three():
#This prints out the accuracies for all 50 iterations of the algorithm
    k = 1
    number_iterations = 50
    X = np.zeros([150, 2])
    x_info = np.zeros(number_iterations)
    y_info = np.zeros(number_iterations)
    for i in range(0, len(x1)):
        X[i] = (x1[i], x2[i])
    for i in range(0, 50): 
        Results = k_means_pp_helper(X, k, 50)
        New_Results = compute_objective(X, Results)
        x_info[i] = k
        y_info[i] = New_Results
        k = k+1

    plt.scatter(x_info, y_info)
    plt.plot(x_info, y_info)
    plt.show()
    final_dist = 0
    differences = np.zeros(len(y_info))
    for j in range(0, len(y_info) - 1):
        differences[j] = abs(y_info[j+1] - y_info[j])
        if(differences[j] > final_dist):
            final_dist = differences[j]
            final_k = j + 2

#This prints out the 50 iterations of the algorithm for the 4th part of the problem and shows how the objective changes with iterations
    k = final_k
    number_iterations = 50
    X = np.zeros([150, 2])
    x_info = np.zeros(number_iterations)
    y_info = np.zeros(number_iterations)

    for i in range(0, len(x1)):
        X[i] = (x1[i], x2[i])

    Results = k_means_pp(X, k, 50)

#This prints out the final clusters with the final k centers
def part_four_two():
    X = np.zeros([150, 2])
    for i in range(0, len(x1)):
        X[i] = (x1[i], x2[i])
    k = 2
    Results = k_means_pp(X, k, 50)

    #Plot the data set
    for i in range(len(x1)):
        plt.scatter(x1[i], x2[i], c = col[i], s = 150, linewidth = 0)

    # Plot the centers
    for i in range(0, len(Results)):
            plt.scatter(Results[i][0], Results[i][1], c = 'black', s = k, linewidth = 3)

plt.show()

print(part_three())
#print(part_four_one())
print(part_four_two())